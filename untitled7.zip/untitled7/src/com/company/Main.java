package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int arroy[]={2,-3,4,6,-7,9,-6,5,2,9,3,4,6,2,1,};
        for (int num:arroy){
            System.out.println(num=32/4);
            break;
        }
    }
}
